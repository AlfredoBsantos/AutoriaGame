<? xml version = "1.0" encoding = "UTF-8" ?>
    <tileset version="1.9" tiledversion="1.9.2" name="chaoBasico" tilewidth="16" tileheight="16" tilecount="1440" columns="40">
        <image source="Overworld.png" width="640" height="576" />
        <tile id="6" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="7" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="8" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="9" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="10" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="11" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="12" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="13" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="14" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="15" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="46" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="47" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="48" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="49" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="50" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="51" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="52" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="53" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="54" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="55" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="86" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="87" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="88" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="89" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="90" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="91" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="92" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="93" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="94" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="95" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="123" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="124" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="125" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="126" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="127" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="128" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="129" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="130" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="131" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="132" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="133" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="134" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="135" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="163" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="164" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="165" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="166" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="167" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="168" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="169" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="170" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="171" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="172" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="173" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="174" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="175" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="187" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="188" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="189" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="190" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="203" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="204" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="205" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="227" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="228" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="229" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="230" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="258" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="259" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="260" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="267" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="298" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="299" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="300" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="307" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="338" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="339" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="340" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="382" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="383" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="384" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="422" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="423" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="424" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="449" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="450" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="462" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="463" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="464" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="489" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="490" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="521" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="522" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="523" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="561" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="562" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="563" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="601" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="602" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="603" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="680" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="720" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="815" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="816" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="817" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="855" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="856" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="857" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="895" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="896" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="897" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="898" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="899" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="900" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="901" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="902" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="938" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="939" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="940" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="941" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="942" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="978" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="979" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="980" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="981" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="982" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1011" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1012" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1013" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1018" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1019" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1020" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1021" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1022" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1051" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1052" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1053" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1058" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1059" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1060" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1061" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1062" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1091" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1092" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1093" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1098" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1099" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1100" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1101" class="Collision">
            <objectgroup>
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
        <tile id="1102" class="Collision">
            <objectgroup draworder="index" id="2">
                <object id="1" name="Plataform" class="Collision" x="0" y="0" width="16" height="12" />
            </objectgroup>
        </tile>
    </tileset>
